#!/bin/sh
#  Copyright (C) 2019  SEIKO EPSON CORPORATION

dpkg -i epson-backend_1.1.1-1_armhf.deb  epson-printer-utility_1.1.1-1_armhf.deb
