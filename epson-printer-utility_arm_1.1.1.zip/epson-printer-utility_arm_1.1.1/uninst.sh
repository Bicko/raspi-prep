#!/bin/sh
#  Copyright (C) 2019  SEIKO EPSON CORPORATION

dpkg -P epson-backend epson-printer-utility
