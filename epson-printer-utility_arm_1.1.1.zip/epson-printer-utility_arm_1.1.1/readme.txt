Epson Printer Utility
======================
Copyright (C) 2019  SEIKO EPSON CORPORATION


Installation
--------------------------------------------
This package needs libqtcore4 and libqtgui4. 
Please install them first as follows.

$ sudo apt install libqtcore4 libqtgui4

Then, Run inst.sh script as root.

$ sudo ./inst.sh


Uninstallation
--------------------------------------------
Run uninst.sh script as root.

$ sudo ./uninst.sh


Execution
--------------------------------------------
$ epson-printer-utility

